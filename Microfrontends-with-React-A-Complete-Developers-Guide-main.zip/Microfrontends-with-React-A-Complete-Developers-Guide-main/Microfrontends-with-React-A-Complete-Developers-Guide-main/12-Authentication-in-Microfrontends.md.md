# [Stephen Grider] Microfrontends with React: A Complete Developer's Guide [ENG, 2020]

<br/>

## 12 Authentication in Microfrontends

<br/>

### 098 Important Notes on Authentication

<br/>

### 099 Implementation Strategies

<br/>

![Application](/img/pic-m12-p01.png?raw=true)

<br/>

### 100 Communicating Auth Changes

<br/>

### 101 Communicating Authentication State

<br/>

### 102 Allowing Signout

<br/>

### 103 Adding an Auth Deploy Config

<br/>

### 104 Verifying Deployment

<br/>

![Application](/img/pic-m12-p02.png?raw=true)

<br/>

---

<br/>

**Marley**

Any questions in english: <a href="https://jsdev.org/chat/">Telegram Chat</a>  
Любые вопросы на русском: <a href="https://jsdev.ru/chat/">Телеграм чат</a>
