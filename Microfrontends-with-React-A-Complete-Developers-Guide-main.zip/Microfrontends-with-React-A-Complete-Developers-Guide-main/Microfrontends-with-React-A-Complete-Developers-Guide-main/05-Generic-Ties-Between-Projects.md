# [Stephen Grider] Microfrontends with React: A Complete Developer's Guide [ENG, 2020]

<br/>

## 05 Generic Ties Between Projects

<br/>

### 038 Assembling the App Component

<br/>

![Application](/img/pic-m05-p01.png?raw=true)

<br/>

![Application](/img/pic-m05-p02.png?raw=true)

<br/>

### 039 Assembling the Container

<br/>

![Application](/img/pic-m05-p03.png?raw=true)

<br/>

### 040 Integration of the Container and Marketing

<br/>

![Application](/img/pic-m05-p04.png?raw=true)

<br/>

### 041 Why Import the Mount Function

<br/>

### 042 Generic Integration

<br/>

![Application](/img/pic-m05-p05.png?raw=true)

<br/>

### 043 Reminder on Shared Modules

<br/>

### 044 Delegating Shared Module Selection

<br/>

---

<br/>

**Marley**

Any questions in english: <a href="https://jsdev.org/chat/">Telegram Chat</a>  
Любые вопросы на русском: <a href="https://jsdev.ru/chat/">Телеграм чат</a>
