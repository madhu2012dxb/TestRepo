# [Stephen Grider] Microfrontends with React: A Complete Developer's Guide [ENG, 2020]

<br/>

## 03 Sharing Dependencies Between Apps

<br/>

### 018 Using Shared Modules

<br/>

![Application](/img/pic-m03-p01.png?raw=true)

<br/>

### 019 Async Script Loading

<br/>

### 020 Shared Module Versioning

<br/>

### 021 Singleton Loading

<br/>

### 022 Sub-App Execution Context

<br/>

### 023 Refactoring Products

<br/>

### 024 Consuming Remote Modules

<br/>

### 025 Refactoring Cart

<br/>

### 026 [Optional] A Funny Gotcha

<br/>

---

<br/>

**Marley**

Any questions in english: <a href="https://jsdev.org/chat/">Telegram Chat</a>  
Любые вопросы на русском: <a href="https://jsdev.ru/chat/">Телеграм чат</a>
